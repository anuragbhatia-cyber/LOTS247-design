export { WalletView } from './WalletView'

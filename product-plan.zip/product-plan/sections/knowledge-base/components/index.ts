export { KnowledgeBase } from './KnowledgeBase'
